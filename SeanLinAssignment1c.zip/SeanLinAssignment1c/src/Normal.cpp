#include "Normal.hpp"
#include <tuple>
#include <vector>

