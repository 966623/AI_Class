#include "Ellipsoid.hpp"
#include <tuple>
#include <vector>

