#ifndef Basiclight_HPP
#define Basiclight_HPP

#include <tuple>
#include <vector>
#include <sstream>
#include <string.h>
#include <math.h>
#include <iostream>
#include "Vec3.hpp"
#include "Light.hpp"

using namespace std;

class Basiclight:public Light {
	public:
		Vec3 color;

	private:
		
}; // end SomeClass

#endif
