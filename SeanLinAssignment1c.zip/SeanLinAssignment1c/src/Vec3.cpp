#include "Vec3.hpp"
#include <tuple>
#include <vector>

