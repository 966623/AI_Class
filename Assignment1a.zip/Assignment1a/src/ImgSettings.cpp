#include "ImgSettings.hpp"
#include <tuple>
#include <vector>

