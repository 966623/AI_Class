#include "Camera.hpp"
#include <tuple>
#include <vector>

